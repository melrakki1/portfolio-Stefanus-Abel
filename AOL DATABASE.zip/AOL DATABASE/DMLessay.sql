--DML ESSAY 10
USE VadidaS

--1 
SELECT [CustomerId] = mc.customerId,
[First Name] = substring(mc.customerName, 1, charindex(' ', mc.customerName)),
[Customer Gender] = mc.customerGender,
[Total Item Purchased] = sum(quantity)
from MsCustomer mc
join TransactionHeader th on mc.customerId = th.customerID
join TransactionDetail td on th.transactionID = td.transactionID
WHERE customerGender = 'Male'
GROUP BY mc.customerID,
substring(mc.customerName, 1, charindex(' ', mc.customerName)),
customerGender
HAVING 1 < SUM(quantity)

--2
SELECT 
[Shoe Id] = REPLACE(ms.shoeId, 'SH', 'Shoes'),
[Staff Id] = mst.staffId,
[Transaction Day] = DATEPART(DAY, transactionDate),
[Shoe Name] = shoeName,
[Total Sold] = SUM(td.quantity)
FROM MsShoe ms
	JOIN TransactionDetail td ON ms.shoeId = td.shoeId
	JOIN TransactionHeader th ON td.transactionId = th.transactionId
	JOIN MsStaff mst ON th.staffId = mst.staffId
WHERE shoePrice>120000
GROUP BY
REPLACE(ms.shoeId, 'SH', 'Shoes'),
	mst.staffId,
	DATEPART(DAY, th.TransactionDate),
	ms.shoeName
HAVING SUM(Quantity) % 2 = 0;

	--3
SELECT
	[Staff Number] = CAST(RIGHT(ms.staffId, 3) AS INT),
	[Staff Name] = UPPER(ms.staffName),
	[Staff Salary] = ms.staffSalary,
	[Total Purchase Made] = SUM(pd.quantity),
	[Max Shoes Purchased] = MAX(pd.quantity) 
FROM MsStaff ms
	JOIN PurchaseHeader ph ON ms.staffId = ph.staffId
	JOIN PurchaseDetail pd ON ph.purchaseId = pd.purchaseId
	JOIN MsShoe msh ON msh.shoeId = pd.shoeId
WHERE msh.shoePrice > 150000
GROUP BY
	CAST(RIGHT(ms.staffId, 3) AS INT),
	UPPER(ms.staffName),
	ms.staffSalary
HAVING SUM(pd.quantity) > 2

--4 
SELECT mv.vendorId,
[Vendor Name] = CONCAT(mv.vendorName, ' Vendor'),
[VendorMail] = UPPER(REPLACE(mv.vendorEmail, '@gmail.com', '@mail.co.id')),
[TotalShoesSold] = SUM(pd.quantity) ,
[MinimumShoesSold] = MIN(pd.quantity)
FROM MsVendor mv
	JOIN PurchaseHeader ph ON mv.vendorId = ph.vendorId
	JOIN PurchaseDetail pd ON ph.purchaseId = pd.purchaseId
GROUP BY mv.vendorId, CONCAT(mv.vendorName, ' Vendor'), UPPER(REPLACE(mv.vendorEmail, '@gmail.com', '@mail.co.id'))
HAVING SUM(quantity) > 13 AND MIN(quantity) > 10;

--5
SELECT 
[Vendor Name] = mv.vendorId, 
[Customer Name] = CONCAT (mv.vendorName , 'company'), 
[Vendor Phone Number] = mv.vendorPhoneNumber,
[Purchase Month] = DATENAME(MONTH, ph.PurchaseDate), 
[quantity] = pd.quantity 
FROM (SELECT AVG(pd.quantity) AS [Average]
FROM PurchaseDetail pd
) AS p, MsVendor mv
JOIN PurchaseHeader ph ON mv.vendorId = ph.vendorId
JOIN PurchaseDetail pd ON ph.purchaseId = pd.purchaseId
WHERE MONTH(ph.PurchaseDate) = 4 AND pd.quantity > p.Average
--6
SELECT 
[TransactionId] = REPLACE(th.TransactionId, 'SA', 'Invoice'),
[Transaction Date] = YEAR(TransactionDate), 
[Shoe Name] = shoeName,
[Shoe Price] = shoePrice,
[Quantity] = CONCAT(quantity,'piece(s)')
FROM (SELECT AVG(ShoePrice) AS SUB
FROM MsShoe) AS ALIAS,
TransactionHeader th JOIN TransactionDetail td ON th.transactionId = td.transactionId
JOIN MsShoe ms ON ms.shoeId = td.shoeId
WHERE shoeName LIKE '%c%'
AND shoePrice > ALIAS.SUB

--7
SELECT 
[PurchaseId] = pd.purchaseId, 
[StaffId] = st.staffId, 
[Staff Name] = UPPER(staffName),
[Purchase Date] = CONVERT (VARCHAR, PurchaseDate, 105),
[Total Expenses] = CONCAT('Rp. ', SUM(ShoePrice*Quantity)) 
FROM( SELECT AVG(shoePrice*quantity) AS SUB
FROM MsShoe ms JOIN PurchaseDetail pd ON ms.shoeId = pd.shoeId
) AS ALIAS, PurchaseDetail pd JOIN PurchaseHeader ph ON pd.purchaseId = ph.purchaseId
JOIN MsStaff st ON ph.staffId = st.staffId
JOIN MsShoe ms ON pd.shoeId = ms.shoeId 
WHERE CAST (RIGHT(st.staffId, 1) AS int) %2 =1
GROUP BY pd.purchaseId, st.staffId, st.staffName, CONVERT (VARCHAR, PurchaseDate, 105), ALIAS.SUB
HAVING SUM (shoeprice * quantity) > ALIAS.SUB


--8
SELECT 
[TransactionId] = th.transactionId,
[StaffId] = ms.StaffId,
[First Name] = SUBSTRING(staffName, 1, CHARINDEX(' ', StaffName)),
[Total Revenue] = SUM(shoePrice * quantity) 
FROM( SELECT AVG(Shoeprice) AS SUB
FROM MsShoe
) as ALIAS,
MsStaff ms JOIN TransactionHeader th ON ms.StaffId = th.StaffId
	JOIN TransactionDetail td ON th. TransactionId = td. TransactionId
	JOIN MsShoe mse ON mse. shoeId = td.ShoeId
		WHERE ms.staffGender = 'Female'
		GROUP BY th.TransactionId,	ms.StaffId,
		SUBSTRING(ms.StaffName, 1 , CHARINDEX (' ',staffName)), ALIAS.SUB
HAVING SUM(Shoeprice * Quantity) > ALIAS.SUB

--9
GO CREATE VIEW [Vendor Max Transaction View] AS 
SELECT
[Vendor Number] = REPLACE(mv.vendorId, 'VE', 'Vendor'),
[Vendor Name] = LOWER(mv.vendorName),
[Total Transaction Made] = COUNT(ph.purchaseId),
[Maximum Quantity] = MAX(pd.quantity)
FROM MsVendor mv
JOIN PurchaseHeader ph ON mv.vendorId = ph.vendorId
JOIN PurchaseDetail pd ON ph.purchaseId = pd.purchaseId
WHERE mv.vendorName LIKE '%a%'
GROUP BY REPLACE(mv.vendorId, 'VE', 'Vendor'), LOWER(mv.vendorName)
HAVING MAX(pd.quantity)>20

--10
GO
CREATE VIEW [Shoes Minimum Transaction View] AS
SELECT
[TransactionId] = th.TransactionId,
[Transaction Date] = TransactionDate,
[Staff Name] = StaffName,
[Staff Email] = UPPER(StaffEmail),
[Minimum Shoes Sold] = MIN(Quantity),
[Total Shoes Sold] = SUM(Quantity)  
FROM
MsStaff ms
JOIN TransactionHeader th ON th.staffId = ms.staffId
JOIN TransactionDetail td ON td.TransactionId = th.TransactionId
JOIN MsShoe mse ON mse.ShoeId = td.ShoeId
WHERE
DATEPART(YEAR, TransactionDate) > 2020
AND ShoePrice > 10000
GROUP BY th.TransactionId,TransactionDate, StaffName, UPPER(StaffEmail)
