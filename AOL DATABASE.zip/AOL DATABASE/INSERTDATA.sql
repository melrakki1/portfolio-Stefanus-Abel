--INSERT INTO

INSERT INTO MsVendor
VALUES
('VE001', 'Putri Anggraini', 'Jl. Sudirman No. 123', 'putri.anggraini@gmail.com', 081234567891),
('VE002', 'Lim Wei Ting', 'Jl. Thamrin No. 456', 'lim.wei.ting@gmail.com', 082345678912),
('VE003', 'Rahmat Sari', 'Jl. Kebon Sirih No. 789','rahmat.sari@gmail.com', 083456789123),
('VE004', 'Wong Mei Ling', 'Jl. Tanah Abang No. 321', 'wong.mei.ling@gmail.com', 084567891234),
('VE005', 'Budi Setiawan', 'Jl. Kemang No. 654', 'budi.setiawan@gmail.com', 085678912345),
('VE006', 'Tan Ying Hui', 'Jl. Senayan No. 987', 'tan.ying.hui@gmail.com', 086789123456),
('VE007', 'Siti Rahmawati', 'Jl. Cideng No. 432', 'siti.rahmawati@gmail.com', 087891234567),
('VE008', 'Lim Wijaya', 'Jl. Mangga Besar No. 765',  'lim.wijaya@gmail.com', 088912345678),
('VE009', 'Angeline Tan', 'Jl. Kelapa Gading No. 234', 'angeline.tan@gmail.com', 089123456789),
('VE010', 'Muhammad Iskandar', 'Jl. Pluit No. 876', 'muhammad.iskandar@gmail.com', 081234567890)



INSERT INTO MsStaff
VALUES
('ST001', 'Nikos Papadopoulos', 'Male', 'nikos.papadopoulos@gmail.com', 'Jl. Raya No.1', 250000),
('ST002', 'Sofia Georgiou', 'Female', 'sofia.georgiou@gmail.com', 'Jl. Baru No.2', 200000),
('ST003', 'Yannis Antonopoulos', 'Male', 'yannis.antonopoulos@gmail.com', 'Jl. Veteran No.3', 300000),
('ST004', 'Eleni Dimitriou', 'Female', 'eleni.dimitriou@gmail.com', 'Jl. Raya No.4', 350000),
('ST005', 'Dimitris Papadakis', 'Male', 'dimitris.papadakis@gmail.com', 'Jl. Baru No.5', 280000),
('ST006', 'Maria Ioannou', 'Female', 'maria.ioannou@gmail.com', 'Jl. Veteran No.6', 220000),
('ST007', 'Giorgos Andreadis', 'Male', 'giorgos.andreadis@gmail.com', 'Jl. Raya No.7', 400000),
('ST008', 'Katerina Papadopoulou', 'Female', 'katerina.papadopoulou@gmail.com', 'Jl. Baru No.8', 300000),
('ST009', 'Eleni Tsakiri', 'Female', 'eleni.tsakiri@gmail.com', 'Jl. Veteran No.9', 240000),
('ST010', 'Dionysis Papadopoulos', 'Male', 'dionysis.papadopoulos@gmail.com', 'Jl. Raya No.10', 320000);

SELECT*FROM MsCustomer
INSERT INTO MsCustomer
VALUES ('CU001', 'Amir Ibrahim', 'Male', '1995-05-12', 'Jl. Raya Kebon Jeruk No. 25', 'amir.ibrahim@gmail.com'),
('CU002', 'Aisha Salah', 'Female', '2000-01-02', 'Jl. Kemang Selatan No. 10', 'aisha.salah@gmail.com'),
('CU003', 'Omar Mahmoud', 'Male', '1998-09-14', 'Jl. H.R. Rasuna Said No. 5', 'omar.mahmoud@gmail.com'),
('CU004', 'Fatima Aling', 'Female', '1997-06-22', 'Jl. Wahid Hasyim No. 7', 'fatima.ali@gmail.com'),
('CU005', 'Ahmed Hassan', 'Male', '1999-12-30', 'Jl. Gajah Mada No. 10', 'ahmed.hassan@gmail.com'),
('CU006', 'Sara Abdel-Rahman', 'Female', '1996-03-08', 'Jl. Sudirman No. 8', 'sara.abdelrahman@gmail.com'),
('CU007', 'Mohamed Said', 'Male', '1994-11-17', 'Jl. Jend. Sudirman No. 10', 'mohamed.said@gmail.com'),
('CU008', 'Yasmin Khalifa', 'Female', '1993-04-18', 'Jl. MH Thamrin No. 7', 'yasmin.khalifa@gmail.com'),
('CU009', 'Khaled Abbas', 'Male', '2001-07-25', 'Jl. Pangeran Antasari No. 18', 'khaled.abbas@gmail.com'),
('CU010', 'Nour Hussein', 'Female', '1997-02-14', 'Jl. Gatot Subroto No. 22', 'nour.hussein@gmail.com')

INSERT INTO MsShoe
VALUES('SH001', 'Nike Air Force 1', 1800000, 'Classic basketball shoes with iconic design'),
('SH002', 'Adidas Stan Smith', 1500000, 'Timeless tennis shoes with clean and simple style'),
('SH003', 'New Balance 574', 1600000, 'Casual sneakers with retro-inspired design'),
('SH004', 'Converse Chuck Taylor All Star', 1200000, 'Iconic canvas shoes suitable for everyday wear'),
('SH005', 'Puma Suede Classic', 1400000, 'Vintage-inspired sneakers made from premium suede'),
('SH006', 'Vans Old Skool', 1300000, 'Skateboarding shoes with signature side stripe'),
('SH007', 'Reebok Club C 85', 1700000, 'Low-top sneakers with a clean and minimalist look'),
('SH008', 'Under Armour Curry 7', 2200000, 'Basketball shoes designed for Stephen Curry'),
('SH009', 'ASICS Tiger Gel-Lyte III', 1900000, 'Retro running shoes with GEL cushioning system'),
('SH010', 'Fila Disruptor II', 2000000, 'Chunky sneakers with a bold and fashionable style')

SELECT*FROM TransactionHeader
INSERT INTO TransactionHeader 
VALUES ('TR001', 'ST004', 'CU001', '2023-05-01'),
	   ('TR002', 'ST009', 'CU002', '2023-05-01'),
	   ('TR003', 'ST008', 'CU003', '2023-05-02'),
	   ('TR004', 'ST007', 'CU004', '2023-05-02'),
	   ('TR005', 'ST006', 'CU005', '2023-05-03'),
	   ('TR006', 'ST005', 'CU006', '2023-05-03'),
	   ('TR007', 'ST004', 'CU007', '2023-05-04'),
	   ('TR008', 'ST003', 'CU008', '2023-05-04'),
	   ('TR009', 'ST002', 'CU009', '2023-05-05'),
	   ('TR010', 'ST001', 'CU010', '2023-05-05'),
	   ('TR011', 'ST008', 'CU001', '2023-05-06'),
	   ('TR012', 'ST009', 'CU002', '2023-05-06'),
	   ('TR013', 'ST008', 'CU003', '2023-05-07'),
	   ('TR014', 'ST007', 'CU004', '2023-05-07'),
	   ('TR015', 'ST006', 'CU005', '2023-05-08'),
	   ('TR016', 'ST005', 'CU006', '2023-05-08'),
	   ('TR017', 'ST004', 'CU007', '2023-05-09'),
	   ('TR018', 'ST003', 'CU008', '2023-05-09'),
	   ('TR019', 'ST002', 'CU009', '2023-05-10'),
	   ('TR020', 'ST001', 'CU010', '2023-05-10'),
	   ('TR021', 'ST003', 'CU001', '2023-05-11'),
	   ('TR022', 'ST009', 'CU002', '2023-05-11'),
	   ('TR023', 'ST008', 'CU003', '2023-05-12'),
	   ('TR024', 'ST007', 'CU004', '2023-05-12'),
	   ('TR025', 'ST006', 'CU005', '2023-05-13')
	 
INSERT INTO TransactionDetail
VALUES 
('TR001', 'SH001', 2),
('TR002', 'SH002', 5),
('TR003', 'SH003', 8),
('TR004', 'SH004', 3),
('TR005', 'SH005', 6),
('TR006', 'SH006', 10),
('TR007', 'SH007', 4),
('TR008', 'SH008', 7),
('TR009', 'SH009', 9),
('TR010', 'SH010', 3),
('TR011', 'SH003', 4),
('TR012', 'SH002', 5),
('TR013', 'SH001', 7),
('TR014', 'SH010', 5),
('TR015', 'SH009', 2),
('TR016', 'SH008', 6),
('TR017', 'SH005', 7),
('TR018', 'SH002', 9),
('TR019', 'SH001', 3),
('TR020', 'SH005', 4),
('TR021', 'SH008', 2),
('TR022', 'SH003', 6),
('TR023', 'SH004', 6),
('TR024', 'SH007', 7),
('TR025', 'SH009', 10);

INSERT INTO PurchaseHeader
VALUES ('PU001', 'ST003', 'VE001', '2023-01-02'),
	   ('PU002', 'ST001', 'VE002', '2023-01-05'),
	   ('PU003', 'ST001', 'VE003', '2023-01-09'),
	   ('PU004', 'ST004', 'VE004', '2023-01-14'),
	   ('PU005', 'ST002', 'VE006', '2023-01-20'),
	   ('PU006', 'ST001', 'VE004', '2023-02-03'),
	   ('PU007', 'ST002', 'VE003', '2023-02-08'),
	   ('PU008', 'ST003', 'VE002', '2023-02-12'),
	   ('PU009', 'ST004', 'VE001', '2023-02-19'),
	   ('PU010', 'ST005', 'VE006', '2023-02-25'),
	   ('PU011', 'ST007', 'VE007', '2023-03-02'),
	   ('PU012', 'ST009', 'VE008', '2023-03-08'),
	   ('PU013', 'ST008', 'VE009', '2023-03-14'),
	   ('PU014', 'ST007', 'VE001', '2023-03-20'),
	   ('PU015', 'ST006', 'VE009', '2023-03-26'),
	   ('PU016', 'ST006', 'VE008', '2023-04-01'),
	   ('PU017', 'ST007', 'VE007', '2023-04-06'),
	   ('PU018', 'ST008', 'VE006', '2023-04-12'),
	   ('PU019', 'ST009', 'VE005', '2023-04-18'),
	   ('PU020', 'ST002', 'VE004', '2023-04-24'),
	   ('PU021', 'ST005', 'VE003', '2023-04-29'),
	   ('PU022', 'ST004', 'VE002', '2023-04-01'),
	   ('PU023', 'ST003', 'VE001', '2023-04-04'),
	   ('PU024', 'ST002', 'VE002', '2023-04-07'),
	   ('PU025', 'ST001', 'VE003', '2023-04-10')

INSERT INTO PurchaseDetail
VALUES
('PU001', 'SH002', 10),
('PU002', 'SH004', 20),
('PU003', 'SH006', 11),
('PU004', 'SH008', 12),
('PU005', 'SH001', 14),
('PU006', 'SH003', 13),
('PU007', 'SH005', 28),
('PU008', 'SH007', 55),
('PU009', 'SH009', 48),
('PU010', 'SH002', 33),
('PU011', 'SH003', 42),
('PU012', 'SH001', 37),
('PU013', 'SH007', 67),
('PU014', 'SH005', 56),
('PU015', 'SH002', 24),
('PU016', 'SH008', 32),
('PU017', 'SH009', 28),
('PU018', 'SH004', 67),
('PU019', 'SH003', 76),
('PU020', 'SH001', 39),
('PU021', 'SH005', 72),
('PU022', 'SH004', 65),
('PU023', 'SH003', 12),
('PU024', 'SH002', 13),
('PU025', 'SH001', 17)