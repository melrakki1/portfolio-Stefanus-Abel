--DROP DATABASE VadidaS
--CREATE DATABASE VadidaS
CREATE TABLE MsCustomer (
	customerId CHAR(5) PRIMARY KEY CHECK (customerId LIKE('CU[0-9][0-9][0-9]')),
	customerName VARCHAR(255) CHECK(LEN(customerName) > 10) Not null,
	customerGender CHAR(10) CHECK(customerGender IN('Male', 'Female')) NOT NULL,
	customerDOB DATE CHECK (DATEDIFF(YEAR, customerDOB, GETDATE()) >= 17) not null,
	customerAddress VARCHAR(255) NOT NULL,
	customerEmail VARCHAR(255) CHECK (customerEmail LIKE('%@gmail.com')) NOT NULL
	)

CREATE TABLE MsVendor (
	vendorId CHAR(5) PRIMARY KEY CHECK(vendorId LIKE('VE[0-9][0-9][0-9]')),
	vendorName CHAR(255) NOT NULL,
	vendorAddress VARCHAR(255) NOT NULL,
	vendorEmail VARCHAR(255) CHECK(vendorEmail LIKE('%@gmail.com')) NOT NULL,
	vendorPhoneNumber BIGINT NOT NULL
	)

CREATE TABLE MsShoe (
	shoeId CHAR(5) PRIMARY KEY CHECK(shoeId LIKE('SH[0-9][0-9][0-9]')),
	shoeName CHAR(255) NOT NULL,
	shoePrice INT NOT NULL,
	shoeDescription CHAR(255) NOT NULL
)

CREATE TABLE MsStaff (
	staffId CHAR(5) PRIMARY KEY CHECK(staffId LIKE('ST[0-9][0-9][0-9]')),
	staffName VARCHAR(255) CHECK(LEN(staffName) > 10) NOT NULL,
	staffGender CHAR(10) CHECK(staffGender IN('Male', 'Female')) NOT NULL,
	staffEmail VARCHAR(255) CHECK(staffEmail LIKE('%@gmail.com')) NOT NULL,
	staffAddress VARCHAR(255) NOT NULL,
	staffSalary INT CHECK(staffSalary BETWEEN 120000 AND 500000) NOT NULL
)


CREATE TABLE TransactionHeader (
	transactionId CHAR(5) PRIMARY KEY CHECK(transactionId LIKE('TR[0-9][0-9][0-9]')) ,
	staffId CHAR(5) FOREIGN KEY(staffId) REFERENCES MsStaff(staffId) NOT NULL,
	customerId CHAR(5) NOT NULL,
	transactionDate DATE NOT NULL,
	
)

CREATE TABLE TransactionDetail (
	transactionId CHAR(5) PRIMARY KEY(transactionId),
	shoeId CHAR(5) FOREIGN KEY(shoeId) REFERENCES MsShoe(shoeId) NOT NULL ,
	quantity INT FOREIGN KEY(transactionId) REFERENCES TransactionHeader(transactionId) NOT NULL
)


CREATE TABLE PurchaseHeader (
	purchaseId CHAR(5) PRIMARY KEY CHECK(purchaseId LIKE('PU[0-9][0-9][0-9]')),
	staffId CHAR(5) FOREIGN KEY(staffId) REFERENCES MsStaff(staffId) NOT NULL,
	vendorId CHAR(5) FOREIGN KEY(vendorId) REFERENCES MsVendor(vendorId) NOT NULL,
	purchaseDate DATE NOT NULL
)

CREATE TABLE PurchaseDetail (
	purchaseId CHAR(5) PRIMARY KEY (purchaseId),
	shoeId CHAR(5) FOREIGN KEY(shoeId) REFERENCES MsShoe(shoeId) NOT NULL,
	quantity INT NOT NULL,
	CONSTRAINT FK_PurchaseHeader_PurchaseDetail FOREIGN KEY(purchaseId) REFERENCES PurchaseHeader(purchaseId),
)