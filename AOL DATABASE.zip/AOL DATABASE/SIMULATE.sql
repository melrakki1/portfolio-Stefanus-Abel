USE VadidaS

--simulate trheader
INSERT INTO TransactionHeader (TransactionId, staffId, customerId, transactionDate) VALUES ('TR026', 'ST006', 'CU005', '2023-05-03')

--simulate trdetail
INSERT INTO TransactionDetail (TransactionId, shoeId, quantity) VALUES('TR026', 'SH006', 2)

--simulate purchaseheader
INSERT INTO PurchaseHeader (purchaseId, staffId, vendorId, purchaseDate) VALUES('PU026', 'ST009', 'VE002', '2023-05-01')

--simulate purchasedetail
INSERT INTO PurchaseDetail (purchaseId, shoeId, quantity) VALUES('TR026', 'SH004', 2)