package main;

import Util.Connect;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.Detail;
import model.Product;
import model.Transaction;

public class History {
	private Stage stage;
	private Scene scene;
	private BorderPane bp;
	private GridPane gp;
	private MenuBar menu;
	private Menu menu_acc, menu_user;
	private MenuItem item_home, item_cart, item_history, item_login;
	private Label user_lbl, transaction_lbl,total_lbl;
	private TableView<Transaction> tb1;
	private TableView<Detail> tb2;
	private final Connect connect = Connect.getInstance();
	
	private void initialize() {
		stage = new Stage();
		gp = new GridPane();
		bp = new BorderPane();
		scene = new Scene(bp, 800, 700);
		menu = new MenuBar();
		menu_acc = new Menu("Account");
		menu_user = new Menu("User");
		item_home = new MenuItem("Home");
		item_cart = new MenuItem("Cart");
		item_history = new MenuItem("History");
		item_login = new MenuItem("Login");
		user_lbl = new Label("Transaction");
		transaction_lbl = new Label("Transaction");
		total_lbl = new Label("Total Price: ");
		tb1 = new TableView<Transaction>();
		tb2 = new TableView<Detail>();
		bp.setCenter(gp);
		gp.add(user_lbl, 0, 0);
		gp.add(tb1, 0, 1);
		gp.add(transaction_lbl, 1, 0);
		gp.add(tb2, 1, 1);
		gp.add(total_lbl, 1, 2);
		bp.setTop(menu);
		
		menu.getMenus().addAll(menu_acc, menu_user);
		menu_user.getItems().addAll(item_home, item_cart, item_history);
		menu_acc.getItems().addAll(item_login);
		}
	
	private void initialtable() {
		TableColumn<Transaction, String> tIDColumn = new TableColumn<>("Transaction ID");
        tIDColumn.setCellValueFactory(new PropertyValueFactory<>("transactionID")); 

        TableColumn<Transaction, String> uIDColumn = new TableColumn<>("User ID");
        uIDColumn.setCellValueFactory(new PropertyValueFactory<>("userID")); 

        
        tb1.getColumns().addAll(tIDColumn, uIDColumn);
        
        TableColumn<Detail, String> transactionColumn = new TableColumn<>("Transaction ID");
        transactionColumn.setCellValueFactory(new PropertyValueFactory<>("transaction")); 

        TableColumn<Detail, String> idColumn = new TableColumn<>("User ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("user")); 
        
        TableColumn<Detail, Integer> qtyColumn = new TableColumn<>("Quantity");
        qtyColumn.setCellValueFactory(new PropertyValueFactory<>("quantity")); 
        
        tb2.getColumns().addAll(transactionColumn, idColumn, qtyColumn);
	}
	
	private void eventhandler() {
		this.item_home.setOnAction(e ->{
			Home home = new Home(stage);
		});
		
		this.item_cart.setOnAction(e ->{
			Cart cart = new Cart(stage);
		});
		
		this.item_login.setOnAction(event -> {
            Login login = new Login(stage);
        });
	}
	public History(Stage stage){
		initialize();
		initialtable();
		eventhandler();
		this.stage = stage;
		this.stage.setScene(scene);
		this.stage.show();
	}
}
