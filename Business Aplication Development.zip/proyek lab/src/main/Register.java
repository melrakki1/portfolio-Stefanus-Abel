package main;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import Util.Connect;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Register{
	private Label register_lbl, email_lbl, username_lbl, password_lbl, confirm_lbl, phone_lbl, gender_lbl, address, lbl;
	private TextField email_tf, username_tf, phone_tf;
	private PasswordField password_f, cpassword;
	private RadioButton male, female;
	private ToggleGroup gender;
	private TextArea address_ta;
	private CheckBox cb;
	private GridPane gp;
	private Button register_btn;
	private Scene scene;
	private Stage stage;
	private BorderPane bp;
	private HBox hb1;
	private Menu register;
	private MenuBar menuBar;
	private MenuItem login;
	private VBox vb1;
	
	private void initialize() {
		bp = new BorderPane();
		gp = new GridPane();
		
		register_lbl = new Label("Register");
		email_lbl = new Label("Email:");
		username_lbl = new Label("Username:");
		password_lbl = new Label("Password:");
		confirm_lbl = new Label("Confirm Password:");
		phone_lbl = new Label("Phone Number:");
		gender_lbl = new Label("Gender:");
		address = new Label("Address:");
		email_tf = new TextField();
		username_tf = new TextField();
		phone_tf = new TextField();
		password_f = new PasswordField();
		cpassword = new PasswordField();
		male = new RadioButton("Male");
		female = new RadioButton("Female");
		gender = new ToggleGroup();
		address_ta = new TextArea();
		cb = new CheckBox("I Agree to Term & Conditions");
		register_btn = new Button("Register");
		
		vb1 = new VBox();
		
		register = new Menu("Register");
		menuBar = new MenuBar();
		login = new MenuItem("Login");
		
		hb1 = new HBox();
		scene = new Scene(bp, 800, 700);
		
		bp.setCenter(gp);
		gp.setAlignment(Pos.CENTER);
		gp.add(register_lbl, 0, 0);
		gp.add(email_lbl, 0, 1);
		gp.add(email_tf, 0, 2);
		gp.add(username_lbl, 0, 3);
		gp.add(username_tf, 0, 4);
		gp.add(password_lbl, 0, 5);
		gp.add(password_f, 0, 6);
		gp.add(confirm_lbl, 0, 7);
		gp.add(cpassword, 0, 8);
		gp.add(phone_lbl, 0, 9);
		gp.add(phone_tf, 0, 10);
		gp.add(gender_lbl, 0, 11);
		gp.add(hb1, 0, 12);
		gp.add(address, 0, 13);
		gp.add(address_ta, 0, 14);
		gp.add(cb, 0, 15);
		gp.add(register_btn, 0, 16);
		gp.setHalignment(register_btn, HPos.RIGHT);
		bp.setTop(vb1);
		hb1.getChildren().addAll(male, female);
		male.setToggleGroup(gender);
		female.setToggleGroup(gender);
		
		register.getItems().add(login);
		menuBar.getMenus().addAll(register);
		vb1.getChildren().add(menuBar);
		
		register_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		
		email_tf.setPromptText("Input Email");
		username_tf.setPromptText("Input an unique username");
		password_f.setPromptText("Input password");
		cpassword.setPromptText("Confirm password");
		phone_tf.setPromptText("Example: +6212345678901");
		address_ta.setPromptText("Input address");
		
		
	}
	
	private void eventHandler() {
		register_btn.setOnMouseClicked (event ->{
			 String email = email_tf.getText();
	            String username = username_tf.getText();
	            String password = password_f.getText();
	            String phone = phone_tf.getText();
	            String selectedGender = male.isSelected() ? "Male" : "Female";
	            String address = address_ta.getText();
	            String role = "User";
	            Connect.getInstance().addUser(email, username, password, phone, address, selectedGender, Connect.getInstance().generateUserId(), role);
	            
	          
	        
	            
	            Login login = new Login(stage);
	            
	        });

	        this.login.setOnAction(event -> {
	            Login login = new Login(stage);
	        });
	}

	
		
	private boolean validasi(String email, String username, String password2, String cPassword2,String phone, String address2) {
		Alert alert = new Alert(AlertType.ERROR);
		if (email_tf.getText().isEmpty() || !email_tf.getText().endsWith("@hoodie.com")) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("Wrong Credential");
	        alert.showAndWait();
		}
		else if (username_tf.getText().isEmpty()) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("Username already taken");
	        alert.showAndWait();
		}
		else if (password_f.getText().isEmpty()) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("Fill password");
	        alert.showAndWait();
		}
		else if (!cpassword.getText().equals(password_f.getText())) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("confirm password must be same as password");
	        alert.showAndWait();
		}
		else if (!phone_tf.getText().startsWith("+62")) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("input correct phone number");
	        alert.showAndWait();
		}
		else if (!(male.isSelected() || female.isSelected())) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("Choose male/female");
	        alert.showAndWait();
		}
		else if (address_ta.getText().isEmpty()) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("Fill Address");
	        alert.showAndWait();
		}
		else if (!cb.isSelected()) {
			alert.setTitle("Error");
	        alert.setHeaderText("Error");
	        alert.setContentText("Check terms and condition");
	        alert.showAndWait();
		}
	
		return false;
	}
	
		
	
	public Register(Stage stage) {
		initialize();
		eventHandler();
		this.stage = stage;
		this.stage.setScene(scene);
		this.stage.show();
	}
	
}
