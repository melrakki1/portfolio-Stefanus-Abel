package main;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Util.Connect;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Product;
import model.User;

public class Home {
	private Stage stage;
	private Scene scene;
	private MenuBar menu;
	private Menu menu_acc, menu_user;
	private MenuItem item_home, item_cart, item_history, item_login;
	private Label title_lbl, detail_lbl, id_lbl, name_lbl, price_lbl, qty_lbl, total_lbl;
	private Spinner<Integer> spin;
	private Button cart_btn; 
	private ListView<Product> lv;
	private VBox vb;
	private HBox hb;
	private BorderPane bp;
	private GridPane gp;
	private final Connect connect = Connect.getInstance();
	
	
	
	private void initialize() {
		stage = new Stage();
		gp = new GridPane();
		bp = new BorderPane();
		scene = new Scene(bp, 800, 700);
		vb = new VBox();
		hb = new HBox();
		
		menu = new MenuBar();
		menu_acc = new Menu("Account");
		menu_user = new Menu("User");
		item_home = new MenuItem("Home");
		item_cart = new MenuItem("Cart");
		item_history = new MenuItem("History");
		item_login = new MenuItem("Login");
		
		title_lbl = new Label("hO-Ohdie");
		detail_lbl = new Label("Hoodie's Detail");
		id_lbl = new Label("Select Hoodie");
		name_lbl = new Label("");
		price_lbl = new Label(""); 
		qty_lbl = new Label("Quantity: ");
		total_lbl = new Label("");
		cart_btn = new Button("Add to Cart");
		spin = new Spinner<>(1,100,1);
		hb.getChildren().addAll(spin, total_lbl);
		lv = new ListView<Product>();
		vb.getChildren().addAll(detail_lbl, id_lbl, name_lbl, price_lbl, qty_lbl, hb, cart_btn);
		vb.setAlignment(Pos.CENTER_LEFT);
		bp.setLeft(gp);
		gp.setAlignment(Pos.TOP_LEFT);
		gp.add(title_lbl, 0, 0);
		gp.add(lv, 0, 1);
		gp.add(vb, 1, 1);
		bp.setTop(menu);
		
		title_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		detail_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		menu.getMenus().addAll(menu_acc, menu_user);
		menu_user.getItems().addAll(item_home, item_cart, item_history);
		menu_acc.getItems().addAll(item_login);
		
	}
	
	private void listInitiation() {
		String query = "SELECT HoodieID, HoodieName, HoodiePrice FROM Hoodie";
        try {
            ResultSet resultSet = connect.execQuery(query);
            ObservableList<Product> productlist = FXCollections.observableArrayList();

            while (resultSet.next()) {
                String id = resultSet.getString("HoodieID"); 
                String name = resultSet.getString("HoodieName"); 
                double price = resultSet.getDouble("HoodiePrice");
                

                
                Product product = new Product(id, name, price); 
                productlist.add(product);
            }

            lv.setItems(productlist); 
            lv.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                if (newValue != null) {
                    id_lbl.setText("Hoodie ID: " + newValue.getId());
                    name_lbl.setText("Name: " + newValue.getName());
                    price_lbl.setText("Price: " + newValue.getPrice());
                    total_lbl.setText("Total price: " + newValue.getPrice() * spin.getValue());
                }
            });

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
		
	
	
	private void eventhandler() {
		this.item_history.setOnAction(e ->{
			History history = new History(stage);
		});
		this.item_cart.setOnAction(e ->{
			Cart cart = new Cart(stage);
		});
		this.item_login.setOnAction(event -> {
            Login login = new Login(stage);
        });
		
		
	}
	
	public Home(Stage stage){
		initialize();
		listInitiation();
		eventhandler();
		this.stage = stage;
		this.stage.setScene(scene);
		this.stage.show();
	}
}
