package main;

import java.sql.ResultSet;
import java.sql.SQLException;

import Util.Connect;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.CartView;

public class Cart {
	private Stage stage;
	private Scene scene;
	private BorderPane bp;
	private GridPane gp;
	private MenuBar menu;
	private Menu menu_acc, menu_user;
	private MenuItem item_home, item_cart, item_history;
	private TableView<CartView> tv;
	private Label cart_lbl, detail_lbl, id_lbl, name_lbl, price_lbl,qty_lbl, total_lbl, contact_lbl, email_lbl, phone_lbl, address_lbl, ctotal_lbl;
	private Button checkout_btn, remove_btn;
	private VBox vb, vb1;
	
    private final Connect connect = Connect.getInstance(); 

	
	private void initialize() {
		stage = new Stage();
		gp = new GridPane();
		bp = new BorderPane();
		scene = new Scene(bp, 800, 700);
		menu = new MenuBar();
		menu_acc = new Menu("Account");
		menu_user = new Menu("User");
		item_home = new MenuItem("Home");
		item_cart = new MenuItem("Cart");
		item_history = new MenuItem("History");
		cart_lbl = new Label("Dummy Cart");
		detail_lbl = new Label("Hoodie's Detail");
		id_lbl = new Label("Hoodie ID: ");
		name_lbl = new Label("Name: ");
		price_lbl = new Label("Price: ");
		qty_lbl = new Label("Quantity: ");
		total_lbl = new Label("Total Price: ");
		contact_lbl = new Label("Contact Information");
		email_lbl = new Label("Email");
		phone_lbl = new Label("Phone");
		address_lbl = new Label("Address");
		ctotal_lbl = new Label("Cart Total Price: ");
		checkout_btn = new Button("Checkout");
		remove_btn = new Button("Remove from Cart");
		
		vb1 = new VBox();
		vb = new VBox();
		tv = new TableView<>();
		
		
		
		bp.setTop(menu);
		
		menu.getMenus().addAll(menu_acc, menu_user);
		menu_user.getItems().addAll(item_home, item_cart, item_history);
		
		bp.setLeft(tv);
		
//		bp.setTop(cart_lbl);
		bp.setCenter(gp);
		vb.getChildren().addAll(detail_lbl, id_lbl, name_lbl, price_lbl, qty_lbl, total_lbl,remove_btn);
		vb1.getChildren().addAll(contact_lbl, email_lbl, phone_lbl, address_lbl, ctotal_lbl, checkout_btn);
		
		gp.setHalignment(checkout_btn, HPos.RIGHT);
		gp.add(vb, 3, 1);
		gp.add(vb1, 3, 4);
		
		cart_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		contact_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		ctotal_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));

		detail_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
	}
	
	private void getData() {
		 String query = "SELECT h.HoodieID, h.HoodieName, c.Quantity from Cart c join Hoodie h ON c.HoodieID = h.HoodieID";
	        try {
	            ResultSet resultSet = connect.execQuery(query);
	            while (resultSet.next()) {
	            	String hoodieID = resultSet.getString("HoodieID");
	                String hoodieName = resultSet.getString("HoodieName");
	                int quantity = resultSet.getInt("Quantity");
	                CartView cartView = new CartView(hoodieID, hoodieName, quantity, quantity);
	                tv.getItems().add(cartView);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	
	private void initialTable() {
		//TableColumn<CartView, String> 
	}
	
	
	private void eventhandler() {
		this.item_home.setOnAction(e ->{
			Home home = new Home(stage);
		});
		
		this.item_history.setOnAction(e ->{
			History history = new History(stage);
		});
	}
	
	public Cart(Stage stage){
		initialize();
		eventhandler();
		getData();
		this.stage = stage;
		this.stage.setScene(scene);
		this.stage.show();
	}
}
