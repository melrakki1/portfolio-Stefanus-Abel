package main;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class Confirm {
	private Stage stage;
	private Scene scene;
	private Label confirm_lbl;
	private Button payment_btn, cancel_btn;
}
