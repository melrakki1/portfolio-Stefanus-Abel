package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Util.Connect;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.User;

public class Login {
	private Stage stage;
	private Scene scene;
	private GridPane gp;
	private BorderPane bp;	
	private Label login_lbl, username_lbl, password_lbl;
	private TextField username_tf;
	private PasswordField password_f;
	private Button login_btn;
	private HBox hb1, hb2;
	private VBox vb1;
	private Menu login;
	private MenuBar menuBar;
	private MenuItem register;
	private ArrayList<User> arr_user = new ArrayList<>();
	private final Connect connect = Connect.getInstance();
	 

	private void initialize() {
		

		gp = new GridPane();
		bp = new BorderPane();
		hb1 = new HBox();
		hb2 = new HBox();
		login_lbl = new Label("Login");
		username_lbl = new Label("Username");
		password_lbl = new Label("Password");
		username_tf = new TextField();
		password_f = new PasswordField();
		login_btn = new Button("Login");
		
		login = new Menu("Login");
		menuBar = new MenuBar();
		register = new MenuItem("Register");
		
		vb1 = new VBox();
		
		scene = new Scene(bp, 800, 700);
		gp.add(login_lbl, 0, 0);
		gp.add(hb1, 0, 1);
		gp.add(hb2, 0, 2);
		gp.add(login_btn, 0, 3);
		hb1.getChildren().addAll(username_lbl, username_tf);
		hb2.getChildren().addAll(password_lbl, password_f);
		bp.setTop(vb1);
		bp.setCenter(gp);
		hb1.setSpacing(10);
		hb2.setSpacing(13);
		gp.setVgap(20);
		GridPane.setHalignment(login_lbl, HPos.CENTER);
		GridPane.setHalignment(login_btn, HPos.CENTER);
		gp.setAlignment(Pos.CENTER);
		login_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		login_btn.setPrefWidth(210);
		
		login.getItems().add(register);
		menuBar.getMenus().add(login);
		vb1.getChildren().add(menuBar);
		
		
		username_tf.setPromptText("Input Username");
		password_f.setPromptText("Input password");
		
	}
	 private boolean authenticateUser(String username, String password) {
	        String query = "SELECT * FROM user WHERE username = ? AND password = ?";
	        try {
	            PreparedStatement ps = connect.prepareStatement(query);
	            ps.setString(1, username);
	            ps.setString(2, password);
	            ResultSet rs = ps.executeQuery();
	            return rs.next(); 
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	        
	    }
	 
	 private String authenticate(String username, String password) {
		 String role = null;
		    String query = "SELECT Role FROM user WHERE username = ? AND password = ?";
		    try {
		        PreparedStatement ps = connect.prepareStatement(query);
		        ps.setString(1, username);
		        ps.setString(2, password);
		        ResultSet rs = ps.executeQuery();
		        if (rs.next()) {
		            role = rs.getString("Role");
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return role;
	 }
	 
	private void eventHandler() {

        login_btn.setOnAction(event -> {
            String username = username_tf.getText();
            String password = password_f.getText();
            String userRole = authenticate(username, password);

            if (userRole !=  null) {
            	if (userRole.equals("User")) {
            		Home home = new Home(stage);
				}
            	else {
					Edit edit = new Edit(stage);
				}
            } else {
            	 Alert alert = new Alert(AlertType.ERROR);
                 alert.setTitle("Error");
                 alert.setHeaderText("Error");
                 alert.setContentText("Wrong Credential");
                 alert.showAndWait();
            }
        });
		register.setOnAction(event ->{
			Register register = new Register(stage);
		});
	}
		public Login(Stage stage){
			initialize();
			eventHandler();
			this.stage = stage;
			this.stage.setScene(scene);
			this.stage.show();
		}
	
	
	
	
}
