package main;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Util.Connect;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Product;


public class Edit {
	private Stage stage;
	private Scene scene;
	private BorderPane bp;
	private GridPane gp;
	private Label product_lbl, update_lbl, id_lbl, name_lbl, price_lbl, insert_lbl, iName_lbl, iPrice_lbl;
	private TextField uPrice_tf, name_tf, price_tf;
	private Button insert_btn, update_btn, remove_btn;
	private TableView<Product> tv;
	private Menu menu_acc, menu_admin;
	private MenuItem item_login;
	private MenuBar menu;
	private VBox vb;
	private HBox hb1, hb2, hb3, hb4;
	private final Connect connect = Connect.getInstance();
	
	private void initialize() {
		stage = new Stage();
		bp = new BorderPane();
		gp = new GridPane();
		scene = new Scene(bp, 800, 700);
		tv = new TableView<Product>();
		
		hb1 = new HBox();
		hb2 = new HBox();
		hb3 = new HBox();
		hb4 = new HBox();
		vb = new VBox();
		update_btn = new Button("Update Price");
		remove_btn = new Button("Delete Hoodie");
		product_lbl = new Label("Edit Product");
		update_lbl = new Label("Update & Delete Hoodie(s)");
		id_lbl = new Label("HoodieID");
		price_lbl = new Label("Price: ");
		name_lbl = new Label("Hoodie Name");
		insert_lbl = new Label("Insert Hoodie");
		iName_lbl = new Label("Name: ");
		iPrice_lbl = new Label("Price: ");
		name_tf = new TextField();
		uPrice_tf = new TextField();
		price_tf = new TextField();
		insert_btn = new Button("Insert");
		item_login = new MenuItem();
		
		menu = new MenuBar();
		menu_acc= new Menu("Account");
		menu_admin = new Menu("Menu");
		bp.setTop(menu);
		menu.getMenus().addAll(menu_acc, menu_admin);
		menu_acc.getItems().addAll(item_login);
		hb1.getChildren().addAll(price_lbl, uPrice_tf);
		hb2.getChildren().addAll(update_btn, remove_btn);
		hb3.getChildren().addAll(iName_lbl, name_tf);
		hb4.getChildren().addAll(iPrice_lbl, price_tf);
		vb.getChildren().addAll(update_lbl, id_lbl, name_lbl, hb1, hb2, insert_lbl, hb3, hb4,insert_btn);
		gp.add(product_lbl, 0, 0);
		gp.add(tv, 0, 1);
		vb.setAlignment(Pos.CENTER_LEFT);
		gp.add(vb, 1, 1);
		bp.setLeft(gp);
		gp.setAlignment(Pos.TOP_LEFT);
		
		
		product_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		update_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
		insert_lbl.setFont(Font.font("Roboto", FontWeight.BOLD, FontPosture.ITALIC,30));
	}
	
	private void initialTable() {
		TableColumn<Product, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id")); 

        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name")); 

        TableColumn<Product, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price")); 

        
        tv.getColumns().addAll(idColumn, nameColumn, priceColumn);
        
        
        try {
            String query = "SELECT * FROM Hoodie"; 
            ResultSet resultSet = connect.execQuery(query);

            while (resultSet.next()) {
                String id = resultSet.getString("HoodieID"); 
                String name = resultSet.getString("HoodieName");
                double price = resultSet.getDouble("HoodiePrice");

                Product product = new Product(id, name, price);
                tv.getItems().add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	
	private void eventhandler() {
		tv.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                id_lbl.setText("Hoodie ID: " + newValue.getId());
                name_lbl.setText("Name: " + newValue.getName());
                uPrice_tf.setText( "" + newValue.getPrice());;
                
            }
        });
		 insert_btn.setOnAction(e -> {
		        String name = name_tf.getText();
		        double price = Double.parseDouble(price_tf.getText());
		        Connect.getInstance().addHoodie(connect.getInstance().generateHoodieID(), name, price);
		        refreshTable();
		    });
		 update_btn.setOnMouseClicked(e ->{
		     double price = Double.parseDouble(uPrice_tf.getText());
		     
		     String query = "UPDATE Hoodie SET HoodiePrice = ? WHERE HoodieID = ?";
		     try {
		         PreparedStatement ps = connect.prepareStatement(query);
		         ps.setDouble(1, price);
		         ps.setString(2, id_lbl.getText().substring(10)); 
		         ps.executeUpdate();
		        
		     } catch (SQLException ex) {
		         ex.printStackTrace();
		     }
		     refreshTable(); 
		 });
		 
		 remove_btn.setOnMouseClicked(e ->{
			 String id = id_lbl.getId();
			 String query = "DELETE FROM Hoodie WHERE HoodieID = ?";
			 try {
			        PreparedStatement ps = connect.prepareStatement(query);
			        ps.setString(1, id);;
			        ps.executeUpdate();
			    } catch (SQLException ex) {
			        ex.printStackTrace();
			    }
			 refreshTable();
		 });
		 this.item_login.setOnAction(event -> {
	            Login login = new Login(stage);
	        });
		 
	}


	private void refreshTable() {
		tv.getItems().clear();
		initialTable();
	}

	public Edit(Stage stage){
		initialize();
		initialTable();
		eventhandler();
		this.stage = stage;
		this.stage.setScene(scene);
		this.stage.show();
	}

}