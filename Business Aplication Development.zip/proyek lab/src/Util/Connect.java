package Util;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Connect {

	private final String USERNAME = "root";
	private final String PASSWORD = "";
	private final String DATABASE = "hoohdie";
	private final String HOST = "localhost:3306";
	private final String CONNECTION = String.format("jdbc:mysql://%s/%s", HOST, DATABASE);

	private Connection con;
	private Statement st;

	public static Connect connect;

	public ResultSet rs;

	private Connect() {

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(CONNECTION, USERNAME, PASSWORD);
			st = con.createStatement();

		} catch (Exception e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void addUser(String email, String name, String password, String phone, String address, String gender, String UserID, String role) {
	     String query = "INSERT INTO user (UserID, Email, Username, Password, PhoneNumber, Address, Gender, Role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	     try (PreparedStatement ps = con.prepareStatement(query)) {
	         ps.setString(1, UserID);
	         ps.setString(2, email);
	         ps.setString(3, name);
	         ps.setString(4, password);
	         ps.setString(5, phone);
	         ps.setString(6, address);
	         ps.setString(7, gender);
	         ps.setString(8, role);

	         int affectedRows = ps.executeUpdate();

	         if (affectedRows == 0) {
	             throw new SQLException("Creating user failed, no rows affected.");
	         }
	     } catch (SQLException e) {
	         e.printStackTrace();
	     }
	 }
	
	public String generateUserId() {
	     String query = "SELECT MAX(CAST(SUBSTRING(UserID, 3) AS SIGNED)) + 1 FROM user";

	     try (ResultSet rs = st.executeQuery(query)) {
	         if (rs.next()) {
	             int nextUserId = rs.getInt(1);
	             return String.format("US%03d", nextUserId);
	         }
	     } catch (SQLException e) {
	         e.printStackTrace();
	     }

	     return null;
	 }
	
	public void addHoodie(String HoodieID, String name, double price) {
	     String query = "INSERT INTO Hoodie (HoodieID, HoodieName, HoodiePrice) VALUES (?, ?, ?)";
	     try (PreparedStatement ps = con.prepareStatement(query)) {
	         ps.setString(1, HoodieID);
	         ps.setString(2, name);
	         ps.setDouble(3, price);

	         int affectedRows = ps.executeUpdate();

	         if (affectedRows == 0) {
	             throw new SQLException("Creating user failed, no rows affected.");
	         }
	     } catch (SQLException e) {
	         e.printStackTrace();
	     }
	 }

	public String generateHoodieID() {
	     String query = "SELECT MAX(CAST(SUBSTRING(HoodieID, 3) AS SIGNED)) + 1 FROM Hoodie";

	     try (ResultSet rs = st.executeQuery(query)) {
	         if (rs.next()) {
	             int nextHoodieID = rs.getInt(1);
	             return String.format("HO%03d", nextHoodieID);
	         }
	     } catch (SQLException e) {
	         e.printStackTrace();
	     }

	     return null;
	 }

	
	public static Connect getInstance() {
		if (connect == null) {
			connect = new Connect();
		}

		return connect;
	}

	public ResultSet execQuery(String query) {
		try {
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}

	public void execUpdate(String query) {

		try {
			st.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public PreparedStatement prepareStatement(String query) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ps;		
	}

}
