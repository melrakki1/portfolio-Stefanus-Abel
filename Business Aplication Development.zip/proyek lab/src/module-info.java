module model {
	opens main;
	opens model to javafx.base;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.desktop;
	requires java.sql;
	requires javafx.base;
	
}