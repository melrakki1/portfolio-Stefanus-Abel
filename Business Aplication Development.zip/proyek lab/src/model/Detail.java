package model;

public class Detail {
	private String transactionID;
	private String hoodieID;
	private Integer qty;
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getHoodieID() {
		return hoodieID;
	}
	public void setHoodieID(String hoodieID) {
		this.hoodieID = hoodieID;
	}
	public Integer getQty() {
		return qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public Detail(String transactionID, String hoodieID, Integer qty) {
		super();
		this.transactionID = transactionID;
		this.hoodieID = hoodieID;
		this.qty = qty;
	}
	
}
