package model;

public class Transaction {
	private String transactionID;
	private String userID;
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public Transaction(String transactionID, String userID) {
		super();
		this.transactionID = transactionID;
		this.userID = userID;
	}
	
}
