package model;

public class CartView {
	public String ID;
	private String name;
	private int qty;
	private double price;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public CartView(String iD, String name, int qty, double price) {
		super();
		ID = iD;
		this.name = name;
		this.qty = qty;
		this.price = price;
	}
	
	
}
